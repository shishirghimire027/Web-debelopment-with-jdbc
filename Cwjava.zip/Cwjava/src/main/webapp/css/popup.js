// Get the popup and button elements
const popup = document.getElementById("login-popup");
const button = document.getElementById("add-to-cart");
const close = document.getElementById("close-popup");

// Show the popup when the button is clicked
button.addEventListener("click", () => {
  popup.style.display = "block";
});

// Hide the popup when the close button is clicked
close.addEventListener("click", () => {
  popup.style.display = "none";
});
