
package com.EmployeeManagementSystem.dao;

import java.lang.reflect.InvocationTargetException; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Customer;

import controller.servlets.UserRegister;
import model.PasswordEncryptionWithAes;


import resources.myCredentials;

@SuppressWarnings("unused")
public class DatabaseConnectivity {
	private  static final String dbUrl="jdbc:mysql://localhost:3306/java_coursework";
	private   static final String dbUsername="root";
	private   static final String dbPassword="";
	private static Connection connection;
	
	public DatabaseConnectivity()
	{
		
	}
	public static  Connection getDatabaseConeection()
	{ 
		
		
				try {
					
					if(connection==null)
					{
						synchronized (DatabaseConnectivity.class) {
							if(connection==null)
							{
							Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
							connection=DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
							}
							
						}
					}
					return connection;
					
				} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
						| InvocationTargetException | NoSuchMethodException | SecurityException
						| ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
		return connection;
	}
	public ResultSet selectWhereQuery(String query, String id) {
		Connection databaseConnection = getDatabaseConeection();
		if(databaseConnection != null) {
			try {
				PreparedStatement statement = databaseConnection.prepareStatement(query);
				statement.setString(1, id);
				ResultSet result = statement.executeQuery();
				return result;
			} catch (SQLException e) {
				return null;
			}
		}else {
			return null;
		}
	}

	public Boolean isUserAlreadyRegistered(String username) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(myCredentials.CHECK_LOGIN_INFO);
				statement.setString(1, username);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					return true;		
				}else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
						
	}
	
	public Boolean isUserRegistered(String query, String username, String password) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, username);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					String userDb = result.getString("username");
					String passwordDb  = result.getString("password");
					String decryptedPwd = model.PasswordEncryptionWithAes.decrypt(passwordDb, username);
					if(decryptedPwd!=null && userDb.equals(username) && decryptedPwd.equals(password)) return true;
					else return false;
				}else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
		
	public int isAdmin(String username) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(myCredentials.IS_USER);
				statement.setString(1, username);
				ResultSet result = statement.executeQuery();
				if(result.next()) {
					String role = result.getString("role");
					if(role.toLowerCase() == myCredentials.ADMIN) return 1;
					else return 0;
				}
				else return -1;
			} catch (SQLException e) { return -2; }
		}else { return -3; }
	}
	//	End region Read operation

	//	Start region Create operation
	public int registerUser(String query, model.Customer userModel) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				if(isUserAlreadyRegistered(userModel.getusername())) return -1;
				
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, userModel.getname());
				statement.setString(2, userModel.getusername());
				statement.setString(3, userModel.getCotanct_number());
				statement.setString(4, model.PasswordEncryptionWithAes.encrypt(
						userModel.getusername(), userModel.getPassword()));
				statement.setString(5, userModel.getRole());
				statement.setString(6, userModel.getImageUrlFromPart());

				int result = statement.executeUpdate();
				if(result>=0) return 1;
				else return 0;
			} catch (Exception e) { return -2; }
		}else { return -3; }
	}
	//	End region Create operation
	
	//	Start region Update operation
	public Boolean updateUser(String query, String username) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, username);
				int result = statement.executeUpdate();
				if(result>=0)return true;
				else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	//	End region Update operation
	
	//	Start region Delete operation
	public Boolean deleteUser(String query, String username) {
		Connection dbConnection = getDatabaseConeection();
		if(dbConnection != null) {
			try {
				PreparedStatement statement = dbConnection.prepareStatement(query);
				statement.setString(1, username);
				int result = statement.executeUpdate();
				if(result>=0)return true;
				else return false;
			} catch (SQLException e) { return null; }
		}else { return null; }
	}
	//	End region Delete operation

}
