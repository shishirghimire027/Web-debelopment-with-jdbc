package controller.servlets;

public class product_method {

}
