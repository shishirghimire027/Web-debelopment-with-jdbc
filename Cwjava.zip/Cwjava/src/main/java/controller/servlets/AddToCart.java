package controller.servlets;

import java.io.IOException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import controller.dao.DatabaseConnectivity;
import com.EmployeeManagementSystem.dao.DatabaseConnectivity;

/**
 * Servlet implementation class AddToCart
 */
@WebServlet("/AddToCart")
public class AddToCart extends HttpServlet {
private static final long serialVersionUID = 1L;


    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCart() {
        super();
        // TODO Auto-generated constructor stub
    }

/**
* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
*/
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       
    }
       

/**
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
*/
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String category = request.getParameter("category");
        String brand = request.getParameter("brand");
        String image = request.getParameter("image");
        String price = request.getParameter("price");
        String id = request.getParameter("id");
        String uname = request.getParameter("username");
       
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnectivity.getDatabaseConeection();
            String query = "INSERT INTO cart (id, name, username, price, category, brand, image) VALUES (?, ?, ?, ?, ?, ?, ?)";
            pstmt = conn.prepareStatement(query);
            pstmt.setInt(1, Integer.parseInt(id)); // Parse id as an integer
            pstmt.setString(2, name);
            pstmt.setString(3, uname);
            pstmt.setString(4, price);
            pstmt.setString(5, category);
            pstmt.setString(6, brand);
            pstmt.setString(7, image);

            int row = pstmt.executeUpdate();

            if (row > 0) {
                response.sendRedirect("View/Product.jsp");
            } else {
                System.out.println("Data is not inserted");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}